export function Loading() {
  return <div>Đang tải...</div>;
}