import { useState } from 'react';

const homePage = () => {
    const [data, setData] = useState({});
    return (
        <div>
            {/* body */}
            <div>home page body</div>
        </div>
    );
};

export default homePage;
