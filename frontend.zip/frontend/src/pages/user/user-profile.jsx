import React from 'react';

const UserProfile = () => {
    return <div>user-profile</div>;
};

export default UserProfile;
