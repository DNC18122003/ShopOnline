import React from 'react';

const UserCartTest = () => {
    return <div>userCartTest</div>;
};

export default UserCartTest;
