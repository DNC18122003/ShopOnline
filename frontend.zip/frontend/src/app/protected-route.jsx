const ProtectedRoute = ({ children, requiredRole }) => {
    return <>{children}</>;
};
export default ProtectedRoute;
